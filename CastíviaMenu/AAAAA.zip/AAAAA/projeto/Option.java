import java.util.ArrayList;

    public class Option {

        protected String opString;

        public Option(String opString){
            this.opString = opString;
        }

        public String getOpString() {
            return opString;
        }






}
